% Intrinsic and Extrinsic Camera Parameters
%
% This script file can be directly executed under Matlab to recover the camera intrinsic and extrinsic parameters.
% IMPORTANT: This file contains neither the structure of the calibration objects nor the image coordinates of the calibration points.
%            All those complementary variables are saved in the complete matlab data file Calib_Results.mat.
% For more information regarding the calibration model visit http://www.vision.caltech.edu/bouguetj/calib_doc/


%-- Focal length:
fc = [ 522.128767661419260 ; 484.761159798614590 ];

%-- Principal point:
cc = [ 317.793415983295400 ; 236.399408506921990 ];

%-- Skew coefficient:
alpha_c = 0.000000000000000;

%-- Distortion coefficients:
kc = [ -0.004545850406429 ; -0.037152522364218 ; -0.004318935321376 ; -0.001321124783358 ; 0.000000000000000 ];

%-- Focal length uncertainty:
fc_error = [ 2.388509529202222 ; 2.179750729523406 ];

%-- Principal point uncertainty:
cc_error = [ 3.282442364956632 ; 2.472394925570765 ];

%-- Skew coefficient uncertainty:
alpha_c_error = 0.000000000000000;

%-- Distortion coefficients uncertainty:
kc_error = [ 0.013098725729768 ; 0.041466838301051 ; 0.001740859869159 ; 0.002139242487092 ; 0.000000000000000 ];

%-- Image size:
nx = 640;
ny = 480;


%-- Various other variables (may be ignored if you do not use the Matlab Calibration Toolbox):
%-- Those variables are used to control which intrinsic parameters should be optimized

n_ima = 18;						% Number of calibration images
est_fc = [ 1 ; 1 ];					% Estimation indicator of the two focal variables
est_aspect_ratio = 1;				% Estimation indicator of the aspect ratio fc(2)/fc(1)
center_optim = 1;					% Estimation indicator of the principal point
est_alpha = 0;						% Estimation indicator of the skew coefficient
est_dist = [ 1 ; 1 ; 1 ; 1 ; 0 ];	% Estimation indicator of the distortion coefficients


%-- Extrinsic parameters:
%-- The rotation (omc_kk) and the translation (Tc_kk) vectors for every calibration image and their uncertainties

%-- Image #1:
omc_1 = [ 2.188098e+00 ; 2.142866e+00 ; -1.000509e-01 ];
Tc_1  = [ -3.182212e+02 ; -4.825496e+02 ; 1.537025e+03 ];
omc_error_1 = [ 5.120083e-03 ; 5.920273e-03 ; 1.156277e-02 ];
Tc_error_1  = [ 9.857261e+00 ; 7.857564e+00 ; 8.228879e+00 ];

%-- Image #2:
omc_2 = [ 2.225537e+00 ; 2.176740e+00 ; -1.712625e-01 ];
Tc_2  = [ -1.963644e+02 ; -4.861504e+02 ; 1.888235e+03 ];
omc_error_2 = [ 6.698949e-03 ; 6.967775e-03 ; 1.451106e-02 ];
Tc_error_2  = [ 1.202438e+01 ; 9.614183e+00 ; 9.670276e+00 ];

%-- Image #3:
omc_3 = [ 1.994984e+00 ; 1.957520e+00 ; -4.117461e-01 ];
Tc_3  = [ -2.234620e+02 ; -3.966359e+02 ; 1.853481e+03 ];
omc_error_3 = [ 4.590236e-03 ; 5.686079e-03 ; 9.668115e-03 ];
Tc_error_3  = [ 1.175140e+01 ; 9.415083e+00 ; 8.561723e+00 ];

%-- Image #4:
omc_4 = [ 1.983561e+00 ; 1.926663e+00 ; -3.610979e-01 ];
Tc_4  = [ -2.747368e+02 ; -3.952766e+02 ; 1.537288e+03 ];
omc_error_4 = [ 4.178670e-03 ; 5.349785e-03 ; 8.824472e-03 ];
Tc_error_4  = [ 9.779091e+00 ; 7.814013e+00 ; 7.281848e+00 ];

%-- Image #5:
omc_5 = [ -2.045475e+00 ; -2.057062e+00 ; 6.419070e-01 ];
Tc_5  = [ -7.911135e+01 ; -4.663326e+02 ; 1.739360e+03 ];
omc_error_5 = [ 6.201290e-03 ; 4.355813e-03 ; 1.012918e-02 ];
Tc_error_5  = [ 1.113460e+01 ; 8.801503e+00 ; 7.375819e+00 ];

%-- Image #6:
omc_6 = [ 2.053949e+00 ; 1.971341e+00 ; 1.785972e-01 ];
Tc_6  = [ -2.490374e+02 ; -4.783123e+02 ; 1.486095e+03 ];
omc_error_6 = [ 5.028103e-03 ; 5.253869e-03 ; 9.556010e-03 ];
Tc_error_6  = [ 9.590142e+00 ; 7.596953e+00 ; 8.077021e+00 ];

%-- Image #7:
omc_7 = [ -2.073855e+00 ; -1.968855e+00 ; -2.460942e-01 ];
Tc_7  = [ -2.132637e+02 ; -4.311848e+02 ; 1.497546e+03 ];
omc_error_7 = [ 5.292815e-03 ; 5.953922e-03 ; 1.150675e-02 ];
Tc_error_7  = [ 9.620960e+00 ; 7.745534e+00 ; 8.036581e+00 ];

%-- Image #8:
omc_8 = [ -2.074442e+00 ; -1.967509e+00 ; -2.501144e-01 ];
Tc_8  = [ -2.134775e+02 ; -4.285274e+02 ; 1.493739e+03 ];
omc_error_8 = [ 5.262452e-03 ; 5.934435e-03 ; 1.146175e-02 ];
Tc_error_8  = [ 9.595870e+00 ; 7.724326e+00 ; 8.012349e+00 ];

%-- Image #9:
omc_9 = [ -2.091559e+00 ; -1.984980e+00 ; -2.654456e-01 ];
Tc_9  = [ -2.859434e+02 ; -4.145340e+02 ; 1.339038e+03 ];
omc_error_9 = [ 4.834454e-03 ; 5.312471e-03 ; 1.071283e-02 ];
Tc_error_9  = [ 8.642930e+00 ; 6.963110e+00 ; 7.338824e+00 ];

%-- Image #10:
omc_10 = [ -2.064410e+00 ; -2.088362e+00 ; -6.371446e-01 ];
Tc_10  = [ -2.118215e+02 ; -4.135575e+02 ; 1.124348e+03 ];
omc_error_10 = [ 3.622273e-03 ; 5.416759e-03 ; 9.691772e-03 ];
Tc_error_10  = [ 7.353911e+00 ; 5.841377e+00 ; 6.522509e+00 ];

%-- Image #11:
omc_11 = [ -2.101835e+00 ; -2.017367e+00 ; -2.958481e-01 ];
Tc_11  = [ -3.880641e+01 ; 1.047668e+02 ; 2.210037e+03 ];
omc_error_11 = [ 4.962055e-03 ; 7.390493e-03 ; 1.340899e-02 ];
Tc_error_11  = [ 1.396277e+01 ; 1.136797e+01 ; 1.148930e+01 ];

%-- Image #12:
omc_12 = [ 2.007997e+00 ; 1.955375e+00 ; -5.129305e-01 ];
Tc_12  = [ -2.360813e+01 ; 1.325651e+02 ; 2.587310e+03 ];
omc_error_12 = [ 8.026422e-03 ; 6.894068e-03 ; 1.464082e-02 ];
Tc_error_12  = [ 1.628090e+01 ; 1.322510e+01 ; 1.223863e+01 ];

%-- Image #13:
omc_13 = [ -1.846895e+00 ; -1.746257e+00 ; 8.225354e-01 ];
Tc_13  = [ 2.692317e+02 ; 2.418213e+01 ; 2.458320e+03 ];
omc_error_13 = [ 5.723844e-03 ; 6.261199e-03 ; 9.564893e-03 ];
Tc_error_13  = [ 1.548737e+01 ; 1.255671e+01 ; 1.031006e+01 ];

%-- Image #14:
omc_14 = [ 1.850581e+00 ; 1.861150e+00 ; 4.161500e-01 ];
Tc_14  = [ 8.638898e+01 ; -5.729868e+00 ; 2.094255e+03 ];
omc_error_14 = [ 6.153220e-03 ; 4.629464e-03 ; 9.643026e-03 ];
Tc_error_14  = [ 1.319136e+01 ; 1.072638e+01 ; 1.148880e+01 ];

%-- Image #15:
omc_15 = [ 1.685924e+00 ; 1.736532e+00 ; 5.964095e-01 ];
Tc_15  = [ -1.018088e+02 ; -3.771781e+02 ; 1.121278e+03 ];
omc_error_15 = [ 5.172726e-03 ; 4.759235e-03 ; 7.141275e-03 ];
Tc_error_15  = [ 7.199074e+00 ; 5.712081e+00 ; 6.183891e+00 ];

%-- Image #16:
omc_16 = [ 1.731211e+00 ; 1.746266e+00 ; 6.063506e-01 ];
Tc_16  = [ -1.892524e+02 ; -3.341299e+02 ; 9.873663e+02 ];
omc_error_16 = [ 5.070360e-03 ; 4.454332e-03 ; 7.210223e-03 ];
Tc_error_16  = [ 6.380078e+00 ; 5.056966e+00 ; 5.526935e+00 ];

%-- Image #17:
omc_17 = [ 2.157137e+00 ; 2.037865e+00 ; 2.426882e-01 ];
Tc_17  = [ -2.259147e+02 ; -5.102968e+02 ; 1.350490e+03 ];
omc_error_17 = [ 5.176491e-03 ; 5.150113e-03 ; 1.006992e-02 ];
Tc_error_17  = [ 8.797532e+00 ; 6.909051e+00 ; 7.622032e+00 ];

%-- Image #18:
omc_18 = [ -2.048624e+00 ; -1.986514e+00 ; 6.343622e-01 ];
Tc_18  = [ -2.980636e+02 ; -2.222243e+02 ; 1.505678e+03 ];
omc_error_18 = [ 5.315888e-03 ; 4.336768e-03 ; 8.835437e-03 ];
Tc_error_18  = [ 9.424851e+00 ; 7.645058e+00 ; 6.168167e+00 ];


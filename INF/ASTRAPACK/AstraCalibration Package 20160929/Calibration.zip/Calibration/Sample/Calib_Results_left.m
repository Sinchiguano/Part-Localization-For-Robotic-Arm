% Intrinsic and Extrinsic Camera Parameters
%
% This script file can be directly executed under Matlab to recover the camera intrinsic and extrinsic parameters.
% IMPORTANT: This file contains neither the structure of the calibration objects nor the image coordinates of the calibration points.
%            All those complementary variables are saved in the complete matlab data file Calib_Results.mat.
% For more information regarding the calibration model visit http://www.vision.caltech.edu/bouguetj/calib_doc/


%-- Focal length:
fc = [ 587.504406599426720 ; 545.529194493481330 ];

%-- Principal point:
cc = [ 315.728589332654220 ; 253.033677101788040 ];

%-- Skew coefficient:
alpha_c = 0.000000000000000;

%-- Distortion coefficients:
kc = [ -0.101053767873261 ; 0.219254593224603 ; -0.002978402238665 ; -0.001142645529550 ; 0.000000000000000 ];

%-- Focal length uncertainty:
fc_error = [ 3.321367862181316 ; 3.021086551863282 ];

%-- Principal point uncertainty:
cc_error = [ 4.529722264193384 ; 3.299382533537833 ];

%-- Skew coefficient uncertainty:
alpha_c_error = 0.000000000000000;

%-- Distortion coefficients uncertainty:
kc_error = [ 0.015325625513795 ; 0.048652836676896 ; 0.001893927457626 ; 0.002286756651029 ; 0.000000000000000 ];

%-- Image size:
nx = 640;
ny = 480;


%-- Various other variables (may be ignored if you do not use the Matlab Calibration Toolbox):
%-- Those variables are used to control which intrinsic parameters should be optimized

n_ima = 18;						% Number of calibration images
est_fc = [ 1 ; 1 ];					% Estimation indicator of the two focal variables
est_aspect_ratio = 1;				% Estimation indicator of the aspect ratio fc(2)/fc(1)
center_optim = 1;					% Estimation indicator of the principal point
est_alpha = 0;						% Estimation indicator of the skew coefficient
est_dist = [ 1 ; 1 ; 1 ; 1 ; 0 ];	% Estimation indicator of the distortion coefficients


%-- Extrinsic parameters:
%-- The rotation (omc_kk) and the translation (Tc_kk) vectors for every calibration image and their uncertainties

%-- Image #1:
omc_1 = [ 2.182877e+00 ; 2.144634e+00 ; -9.669445e-02 ];
Tc_1  = [ -2.979649e+02 ; -4.817100e+02 ; 1.535234e+03 ];
omc_error_1 = [ 6.276060e-03 ; 7.184260e-03 ; 1.431675e-02 ];
Tc_error_1  = [ 1.209746e+01 ; 9.322115e+00 ; 1.024037e+01 ];

%-- Image #2:
omc_2 = [ 2.221903e+00 ; 2.178715e+00 ; -1.648009e-01 ];
Tc_2  = [ -1.775406e+02 ; -4.843731e+02 ; 1.887217e+03 ];
omc_error_2 = [ 8.216525e-03 ; 8.449608e-03 ; 1.816353e-02 ];
Tc_error_2  = [ 1.477132e+01 ; 1.142405e+01 ; 1.207191e+01 ];

%-- Image #3:
omc_3 = [ 1.989978e+00 ; 1.957415e+00 ; -4.075447e-01 ];
Tc_3  = [ -2.047060e+02 ; -3.950686e+02 ; 1.852287e+03 ];
omc_error_3 = [ 5.644996e-03 ; 6.898473e-03 ; 1.202373e-02 ];
Tc_error_3  = [ 1.443111e+01 ; 1.120768e+01 ; 1.061321e+01 ];

%-- Image #4:
omc_4 = [ 1.979312e+00 ; 1.926986e+00 ; -3.561753e-01 ];
Tc_4  = [ -2.547815e+02 ; -3.943104e+02 ; 1.536733e+03 ];
omc_error_4 = [ 5.133508e-03 ; 6.491118e-03 ; 1.098906e-02 ];
Tc_error_4  = [ 1.201588e+01 ; 9.302762e+00 ; 9.042897e+00 ];

%-- Image #5:
omc_5 = [ -2.046626e+00 ; -2.063134e+00 ; 6.421193e-01 ];
Tc_5  = [ -5.987010e+01 ; -4.642731e+02 ; 1.739953e+03 ];
omc_error_5 = [ 7.524873e-03 ; 5.384273e-03 ; 1.261724e-02 ];
Tc_error_5  = [ 1.369066e+01 ; 1.048548e+01 ; 9.153940e+00 ];

%-- Image #6:
omc_6 = [ 2.047924e+00 ; 1.971814e+00 ; 1.826947e-01 ];
Tc_6  = [ -2.284680e+02 ; -4.774283e+02 ; 1.485953e+03 ];
omc_error_6 = [ 6.084158e-03 ; 6.389213e-03 ; 1.180170e-02 ];
Tc_error_6  = [ 1.177285e+01 ; 9.011463e+00 ; 1.006088e+01 ];

%-- Image #7:
omc_7 = [ -2.072688e+00 ; -1.975685e+00 ; -2.506346e-01 ];
Tc_7  = [ -1.927474e+02 ; -4.299753e+02 ; 1.496908e+03 ];
omc_error_7 = [ 6.217349e-03 ; 7.144633e-03 ; 1.405597e-02 ];
Tc_error_7  = [ 1.181380e+01 ; 9.212235e+00 ; 9.949907e+00 ];

%-- Image #8:
omc_8 = [ -2.074593e+00 ; -1.975660e+00 ; -2.536223e-01 ];
Tc_8  = [ -1.929544e+02 ; -4.275600e+02 ; 1.493277e+03 ];
omc_error_8 = [ 6.192984e-03 ; 7.127544e-03 ; 1.402524e-02 ];
Tc_error_8  = [ 1.178447e+01 ; 9.187888e+00 ; 9.925135e+00 ];

%-- Image #9:
omc_9 = [ -2.087850e+00 ; -1.988598e+00 ; -2.699084e-01 ];
Tc_9  = [ -2.651528e+02 ; -4.134551e+02 ; 1.338155e+03 ];
omc_error_9 = [ 5.673672e-03 ; 6.397249e-03 ; 1.305246e-02 ];
Tc_error_9  = [ 1.060776e+01 ; 8.276339e+00 ; 9.061554e+00 ];

%-- Image #10:
omc_10 = [ -2.063340e+00 ; -2.095826e+00 ; -6.387188e-01 ];
Tc_10  = [ -1.900553e+02 ; -4.132054e+02 ; 1.124725e+03 ];
omc_error_10 = [ 4.206044e-03 ; 6.449633e-03 ; 1.179739e-02 ];
Tc_error_10  = [ 9.034770e+00 ; 6.954342e+00 ; 8.064131e+00 ];

%-- Image #11:
omc_11 = [ -2.097937e+00 ; -2.019727e+00 ; -2.972443e-01 ];
Tc_11  = [ -2.399214e+01 ; 1.074482e+02 ; 2.210785e+03 ];
omc_error_11 = [ 5.971619e-03 ; 8.955767e-03 ; 1.631856e-02 ];
Tc_error_11  = [ 1.715273e+01 ; 1.352746e+01 ; 1.412285e+01 ];

%-- Image #12:
omc_12 = [ 2.002927e+00 ; 1.954062e+00 ; -5.103153e-01 ];
Tc_12  = [ -1.001534e+01 ; 1.356152e+02 ; 2.587497e+03 ];
omc_error_12 = [ 9.613389e-03 ; 8.235655e-03 ; 1.754314e-02 ];
Tc_error_12  = [ 1.997399e+01 ; 1.568706e+01 ; 1.501968e+01 ];

%-- Image #13:
omc_13 = [ -1.850097e+00 ; -1.754879e+00 ; 8.231798e-01 ];
Tc_13  = [ 2.844394e+02 ; 2.935817e+01 ; 2.463473e+03 ];
omc_error_13 = [ 7.087135e-03 ; 7.838602e-03 ; 1.208239e-02 ];
Tc_error_13  = [ 1.909342e+01 ; 1.506292e+01 ; 1.267458e+01 ];

%-- Image #14:
omc_14 = [ 1.845173e+00 ; 1.861261e+00 ; 4.198521e-01 ];
Tc_14  = [ 1.028037e+02 ; -2.978899e+00 ; 2.095879e+03 ];
omc_error_14 = [ 7.393393e-03 ; 5.639586e-03 ; 1.166539e-02 ];
Tc_error_14  = [ 1.620090e+01 ; 1.275328e+01 ; 1.408563e+01 ];

%-- Image #15:
omc_15 = [ 1.679669e+00 ; 1.736739e+00 ; 5.999625e-01 ];
Tc_15  = [ -8.007754e+01 ; -3.760779e+02 ; 1.122246e+03 ];
omc_error_15 = [ 6.232012e-03 ; 5.884297e-03 ; 8.776503e-03 ];
Tc_error_15  = [ 8.840306e+00 ; 6.793793e+00 ; 7.689582e+00 ];

%-- Image #16:
omc_16 = [ 1.725032e+00 ; 1.746478e+00 ; 6.109045e-01 ];
Tc_16  = [ -1.670210e+02 ; -3.334752e+02 ; 9.875954e+02 ];
omc_error_16 = [ 6.117251e-03 ; 5.498894e-03 ; 8.841873e-03 ];
Tc_error_16  = [ 7.823428e+00 ; 6.006131e+00 ; 6.853273e+00 ];

%-- Image #17:
omc_17 = [ 2.150262e+00 ; 2.038506e+00 ; 2.451414e-01 ];
Tc_17  = [ -2.046864e+02 ; -5.092499e+02 ; 1.350573e+03 ];
omc_error_17 = [ 6.188056e-03 ; 6.197886e-03 ; 1.213251e-02 ];
Tc_error_17  = [ 1.081083e+01 ; 8.198461e+00 ; 9.452366e+00 ];

%-- Image #18:
omc_18 = [ -2.048868e+00 ; -1.992338e+00 ; 6.355999e-01 ];
Tc_18  = [ -2.781222e+02 ; -2.208924e+02 ; 1.506253e+03 ];
omc_error_18 = [ 6.442533e-03 ; 5.362754e-03 ; 1.094184e-02 ];
Tc_error_18  = [ 1.159909e+01 ; 9.089451e+00 ; 7.633688e+00 ];


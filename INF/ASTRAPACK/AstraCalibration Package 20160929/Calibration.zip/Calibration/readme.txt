1. print the calibration checker.(see camera-calibration-checker-board_9x7.pdf)

2. measure the block size of the checker and fill in [Size] of StereoCalib\config.ini 

3. run calibrationtool.exe
a. how to use:
i - switch between IR and RGB
s - save IR and RGB image
Don't press 's' twice until the calibration is finish
c - calibrate
escape - quit

b. what to capture: see Sample

c. please capture more than 15 pairs of color and IR images

4. Once capture enough images, you can press 'c' to start calibration.
a. each time check image is loaded in GUI, you can press SPACE to go to next image
b. the output result: StereoCalib\camera_params.ini

